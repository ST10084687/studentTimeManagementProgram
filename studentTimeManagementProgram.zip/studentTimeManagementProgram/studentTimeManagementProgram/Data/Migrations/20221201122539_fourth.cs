﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace studentTimeManagementProgram.Data.Migrations
{
    public partial class fourth : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
