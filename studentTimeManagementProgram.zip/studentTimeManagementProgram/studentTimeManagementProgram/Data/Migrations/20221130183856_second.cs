﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace studentTimeManagementProgram.Data.Migrations
{
    public partial class second : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Reminder",
                columns: table => new
                {
                    reminderCourseId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    reminderCourseName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    reminderCourseCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    reminderDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Reminder", x => x.reminderCourseId);
                });

            migrationBuilder.CreateTable(
                name: "Semester",
                columns: table => new
                {
                    courseId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    courseName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    courseCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    credits = table.Column<int>(type: "int", nullable: false),
                    classHours = table.Column<int>(type: "int", nullable: false),
                    semesterWeeks = table.Column<int>(type: "int", nullable: false),
                    studyDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    hoursWorked = table.Column<int>(type: "int", nullable: false),
                    startDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    selfStudyHoursPerWeek = table.Column<int>(type: "int", nullable: false),
                    hoursRemaining = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Semester", x => x.courseId);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Reminder");

            migrationBuilder.DropTable(
                name: "Semester");
        }
    }
}
