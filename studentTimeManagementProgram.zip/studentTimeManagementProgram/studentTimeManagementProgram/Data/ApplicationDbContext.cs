﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using studentTimeManagementProgram.Models;

namespace studentTimeManagementProgram.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<studentTimeManagementProgram.Models.Reminder> Reminder { get; set; }
        public DbSet<studentTimeManagementProgram.Models.Semester> Semester { get; set; }
    }
}
