﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using studentTimeManagementProgram.Data;
using studentTimeManagementProgram.Models;

namespace studentTimeManagementProgram.Pages.Semesters
{
    public class DetailsModel : PageModel
    {
        private readonly studentTimeManagementProgram.Data.ApplicationDbContext _context;

        public DetailsModel(studentTimeManagementProgram.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public Semester Semester { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Semester = await _context.Semester.FirstOrDefaultAsync(m => m.courseId == id);

            if (Semester == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
