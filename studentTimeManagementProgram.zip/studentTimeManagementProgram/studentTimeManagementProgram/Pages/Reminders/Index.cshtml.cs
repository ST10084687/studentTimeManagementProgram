﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using studentTimeManagementProgram.Data;
using studentTimeManagementProgram.Models;

namespace studentTimeManagementProgram.Pages.Reminders
{
    public class IndexModel : PageModel
    {
        private readonly studentTimeManagementProgram.Data.ApplicationDbContext _context;

        public IndexModel(studentTimeManagementProgram.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Reminder> Reminder { get;set; }

        public async Task OnGetAsync()
        {
            Reminder = await _context.Reminder.ToListAsync();
        }
    }
}
