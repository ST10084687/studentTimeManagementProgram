﻿using ProgPoeDll;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using static ProgPoeDll.Class1;

namespace studentTimeManagementProgram.Models
{
    public class Semester
    {
        //use of dll
        courseInformation information = new courseInformation();
        //courseInformation information = new courseInformation();
        List<courseInformation> informationList = new List<courseInformation>();

        Class1 cl = new Class1();

        [Key]
        public int courseId { get; set; }
        public string courseName { get; set; }
        public string courseCode { get; set; }
        public int credits { get; set; }
        public int classHours { get; set; }
        public int semesterWeeks { get; set; }


        public DateTime studyDate { get; set; }
        //public int month { get; set; }
        //public string code { get; set; }
        public int hoursWorked { get; set; }
        public DateTime startDate { get; set; }
        //public string name { get; set; }


        public int selfStudyHoursPerWeek
        {
            get
            // int selfStudyHoursPerWeek;
            {
                return (int)Math.Round(((double)(credits * 10) / semesterWeeks) - classHours, MidpointRounding.AwayFromZero);
            }
            set
            { }

        }

        public int hoursRemaining
        {
            get
            {
                return selfStudyHoursPerWeek - hoursWorked;
            }

            set { }
        }

        public string studyDay { get; set; }


    }
}
